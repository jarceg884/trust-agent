#!/usr/bin/env python3
"""Fill AcroForm fields from a UTF-8 JSON file; optionally flatten.

The JSON is a flat object: {"FieldName": "value", "Agree": true, ...}
- text fields: strings
- checkboxes: true/false (or an explicit on-state name like "/Yes")
- radio / dropdown: the export value as a string (see pdf_read.py --fields "options")

Sets NeedAppearances so conforming viewers regenerate field appearances.
Flattening uses pypdf appearance merging; verify visually for exotic widgets.
"""
from __future__ import annotations

import argparse
import json
import sys


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    parser = argparse.ArgumentParser(description="Fill PDF AcroForm fields from JSON (pypdf).")
    parser.add_argument("pdf", help="Input form PDF")
    parser.add_argument("--fields-json", required=True, help="UTF-8 JSON file of field values")
    parser.add_argument("-o", "--output", required=True, help="Output PDF path")
    parser.add_argument("--flatten", action="store_true",
                        help="Make fields read-only and burn appearances into the page")
    parser.add_argument("--password", help="Password if the input is encrypted")
    args = parser.parse_args()

    try:
        from pypdf import PdfReader, PdfWriter
        from pypdf.generic import BooleanObject, NameObject
    except ImportError:
        print("Missing dependency: 'pypdf' is not importable here; rerun with the documents interpreter $PY from the pdf skill's Prerequisites setup block", file=sys.stderr)
        return 2

    with open(args.fields_json, encoding="utf-8") as fh:
        values = json.load(fh)

    reader = PdfReader(args.pdf)
    if reader.is_encrypted:
        if args.password is None or not reader.decrypt(args.password):
            print("Error: input is encrypted; pass --password", file=sys.stderr)
            return 3
    available = set((reader.get_fields() or {}).keys())
    missing = [name for name in values if name not in available]
    if missing:
        print(f"Warning: fields not found in form, skipped: {missing}", file=sys.stderr)

    writer = PdfWriter()
    writer.append(reader)

    # Normalize checkbox booleans to the field's actual on-state name
    # (e.g. "/Yes"): pypdf does not reliably map bare True to the on-state.
    field_info = reader.get_fields() or {}
    fill = {}
    for name, value in values.items():
        if name not in available:
            continue
        if isinstance(value, bool):
            states = [str(s) for s in (field_info[name].get("/_States_") or [])]
            on_state = next((s for s in states if s != "/Off"), "/Yes")
            value = on_state if value else "/Off"
        fill[name] = value
    # Flattening bakes only the fields it is handed and the widgets are removed
    # afterwards, so fields the JSON leaves out are baked with their current value.
    to_write = fill
    if args.flatten:
        to_write = {name: info["/V"] for name, info in field_info.items()
                    if info.get("/V") not in (None, "")}
        to_write.update(fill)
    for page in writer.pages:
        writer.update_page_form_field_values(
            page, to_write, flags=1 if args.flatten else 0,
            auto_regenerate=False, flatten=args.flatten)

    root = writer._root_object
    flattened = args.flatten
    if args.flatten:
        # pypdf's flatten=True merges each widget appearance into page
        # content but intentionally leaves the annotations behind. Remove
        # those widgets and the form dictionary to make the result genuinely
        # non-interactive; preserve unrelated links/comments.
        from pypdf.generic import ArrayObject
        for page in writer.pages:
            annots = page.get("/Annots")
            if not annots:
                continue
            kept = ArrayObject(
                ref for ref in annots
                if ref.get_object().get("/Subtype") != "/Widget")
            if kept:
                page[NameObject("/Annots")] = kept
            else:
                page.pop(NameObject("/Annots"), None)
        root.pop(NameObject("/AcroForm"), None)
    elif "/AcroForm" in root:
        # Let conforming viewers regenerate interactive field appearances.
        root["/AcroForm"][NameObject("/NeedAppearances")] = BooleanObject(True)

    with open(args.output, "wb") as fh:
        writer.write(fh)
    print(json.dumps({"output": args.output, "filled": sorted(fill), "skipped": missing,
                      "flattened": flattened}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
